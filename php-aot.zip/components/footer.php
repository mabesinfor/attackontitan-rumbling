<footer>
    &copy; 2021 - <?php echo date('Y'); ?> - NamaProject
</footer>